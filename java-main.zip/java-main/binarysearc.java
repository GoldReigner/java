public class binarysearc {

}
