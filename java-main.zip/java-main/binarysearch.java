public class binarysearch {

}
