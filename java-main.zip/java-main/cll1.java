public class cll1 {

    public static void main(String[] args) {
        cll list = new cll();
        list.insert(23);
        list.insert(21);
        list.insert(22);
        list.display();

    }
}
