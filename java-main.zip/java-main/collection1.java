public class collection1 {
    public static void main(String[] args) {
        Object arr[] = new Object[10];
        arr[0] = "ankit";
        arr[1] =  23;
        arr[2] = 'a';

        String array[] = new String[10];
        array[0] = "ankit";
//        array[1] = 13;
//        array[2] = 'a';

        
    }
}
