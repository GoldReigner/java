import java.util.*;
public class program1 {
    //==========================================================================================================
    //PALINDROME PROGRAM
    public static void main(String[] args) {
        // we can also check by reversing the strings
//        int n = 455554;
//        Integer no = new Integer(n);
//        String str = no.toString();
//        System.out.println(isPalindrome(str));
//        String reverse = reversePalindrome(str);
//        if(reverse.equals(str)){
//            System.out.println("no is palindrome");
//        }else{
//            System.out.println("no is not palindrome");
//        }
//        }
//        static boolean isPalindrome(String str){
//        str = str.toLowerCase();
//            for(int i = 0 ; i  <= str.length()/2 ;i++){
//                char start = str.charAt(i);
//                char end = str.charAt(str.length()-1-i);
//             //   System.out.println(end);
//                if(start!=end) {
//                    return false;
//                }
//        }
//            return true;
//    }
//    static String reversePalindrome(String str){
//         str = str.toLowerCase();
//         StringBuilder builder = new StringBuilder();
//         builder.append(str);
//         builder.reverse();
//         return builder.toString();
    }
}
